ANUPAM MISTHAN — SECURE WEBSITE PACKAGE

FILES
- index.html       Customer-facing shop
- admin.html       Separate admin login and dashboard
- firestore.rules  Firestore access rules (must be published in Firebase)

IMPORTANT BEFORE PUBLISHING
1. These files use the existing Firebase project configuration and existing admin email from the previous website.
2. Firebase Authentication > Users: make sure the admin account exists and its email is verified.
3. Firebase Authentication > Settings > Authorized domains: keep only domains you actually use, including your GitHub Pages domain.
4. Firebase Console > Firestore Database > Rules: replace the existing rules with firestore.rules and click Publish.
5. Test that a signed-out visitor can read Products but cannot read Orders or write Products. Only the verified admin should read Orders and write Products.
6. Turn on Firebase App Check for the web app and enforce it for Cloud Firestore after testing. This reduces abuse from unauthorized clients but does not replace Security Rules.
7. Use a strong, unique admin password and enable multi-factor authentication if available.
8. Keep customer names, phone numbers and addresses private. Do not publish real customer data in screenshots or public files.

GITHUB PAGES LAYOUT
Upload index.html and admin.html to the repository root. The customer site is the normal site URL. The admin page is at /admin.html. Do not put passwords or service-account keys in either HTML file.

SECURITY NOTES
- Firebase web apiKey is a public project identifier, not an admin password. Security depends on published Firestore Rules.
- The order form currently opens WhatsApp; it does not save orders to Firestore. This avoids storing customer addresses in the database in this version. Admin dashboard keeps product management. The Orders panel is present for a future server-validated order workflow and will remain empty unless orders are created through a trusted backend.
- Do not enable public read access to the orders collection.
- This is a safer baseline, not a guarantee of being impossible to hack. Before real commercial use, have a qualified adult/developer review it and consider a trusted backend for order processing, server-side price validation, abuse/rate limiting and privacy compliance.
